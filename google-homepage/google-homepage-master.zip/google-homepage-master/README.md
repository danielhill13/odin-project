From The Odin Project's [curriculum](http://www.theodinproject.com/web-development-101/html-css)
